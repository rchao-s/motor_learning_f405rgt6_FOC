#include "uart_TR.h"

#include <stdio.h>
#include <stdarg.h>
#include <string.h>


/* =========================================================
 * 私有变量
 * =========================================================
 */

static UART_HandleTypeDef *uart_handle = NULL;


/* DMA发送缓冲区 */
static uint8_t tx_buffer[UART_TX_BUFFER_SIZE];


/* DMA接收缓冲区 */
static uint8_t rx_buffer[UART_RX_BUFFER_SIZE];


/* 发送忙标志 */
static volatile uint8_t tx_busy = 0;


/* 用户接收回调 */
static void (*rx_callback)(uint8_t *data, uint16_t len) = NULL;


/* =========================================================
 * 初始化
 * =========================================================
 */

void UART_TR_Init(UART_HandleTypeDef *huart)
{
    uart_handle = huart;

    tx_busy = 0;

    memset(tx_buffer, 0, sizeof(tx_buffer));
    memset(rx_buffer, 0, sizeof(rx_buffer));
}


/* =========================================================
 * DMA发送
 * =========================================================
 */

uint8_t UART_TR_SendData(const uint8_t *data, uint16_t len)
{
    if (uart_handle == NULL)
    {
        return 0;
    }

    if (data == NULL || len == 0)
    {
        return 0;
    }

    /*
     * 上一次DMA还没结束
     */
    if (tx_busy)
    {
        return 0;
    }

    /*
     * 限制数据长度
     */
    if (len > UART_TX_BUFFER_SIZE)
    {
        len = UART_TX_BUFFER_SIZE;
    }

    /*
     * 数据必须复制到静态缓冲区。
     *
     * 因为 HAL_UART_Transmit_DMA() 返回后，
     * DMA仍然在后台读取这个缓冲区。
     */
    memcpy(tx_buffer, data, len);

    tx_busy = 1;

    if (HAL_UART_Transmit_DMA(
            uart_handle,
            tx_buffer,
            len) != HAL_OK)
    {
        tx_busy = 0;
        return 0;
    }

    return 1;
}


/* =========================================================
 * printf
 * =========================================================
 */

void UART_printf(const char *format, ...)
{
    /*
     * 如果上一帧还没发完，直接丢掉。
     *
     * 对于FOC调试打印，这样比等待UART更好：
     * 不会阻塞主循环。
     */
    if (tx_busy)
    {
        return;
    }

    char temp_buffer[UART_TX_BUFFER_SIZE];

    va_list args;

    va_start(args, format);

    int len = vsnprintf(
        temp_buffer,
        sizeof(temp_buffer),
        format,
        args
    );

    va_end(args);


    if (len <= 0)
    {
        return;
    }

    /*
     * vsnprintf返回值可能大于buffer
     */
    if (len >= UART_TX_BUFFER_SIZE)
    {
        len = UART_TX_BUFFER_SIZE - 1;
    }


    UART_TR_SendData(
        (uint8_t *)temp_buffer,
        (uint16_t)len
    );
}


/* =========================================================
 * 开启DMA + IDLE接收
 * =========================================================
 */

void UART_TR_StartReceiving(void)
{
    if (uart_handle == NULL)
    {
        return;
    }

    /*
     * ReceiveToIdle DMA：
     *
     * 1. 缓冲区满
     * 或
     * 2. UART出现IDLE
     *
     * 都会进入 HAL_UARTEx_RxEventCallback()
     */
    HAL_UARTEx_ReceiveToIdle_DMA(
        uart_handle,
        rx_buffer,
        UART_RX_BUFFER_SIZE
    );


    /*
     * 不需要 Half Transfer 中断。
     *
     * 否则DMA到一半可能也触发一次回调，
     * 对普通串口协议反而麻烦。
     */
    if (uart_handle->hdmarx != NULL)
    {
        __HAL_DMA_DISABLE_IT(
            uart_handle->hdmarx,
            DMA_IT_HT
        );
    }
}


/* =========================================================
 * 注册用户接收回调
 * =========================================================
 */

void UART_TR_RegisterRxCallback(
    void (*callback)(uint8_t *data, uint16_t len))
{
    rx_callback = callback;
}


/* =========================================================
 * 查询发送状态
 * =========================================================
 */

uint8_t UART_TR_IsTxBusy(void)
{
    return tx_busy;
}


/* =========================================================
 * HAL UART DMA发送完成回调
 *
 * HAL自动调用
 *
 * main.c 不需要再写：
 *
 * HAL_UART_TxCpltCallback(...)
 *
 * =========================================================
 */

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (uart_handle == NULL)
    {
        return;
    }

    /*
     * 只处理我们初始化的UART
     */
    if (huart->Instance != uart_handle->Instance)
    {
        return;
    }

    /*
     * DMA发送完成
     */
    tx_busy = 0;
}


/* =========================================================
 * HAL UART ReceiveToIdle 回调
 *
 * HAL自动调用
 * =========================================================
 */

void HAL_UARTEx_RxEventCallback(
    UART_HandleTypeDef *huart,
    uint16_t Size)
{
    if (uart_handle == NULL)
    {
        return;
    }

    /*
     * 不是我们使用的UART
     */
    if (huart->Instance != uart_handle->Instance)
    {
        return;
    }


    /*
     * 把收到的数据交给用户
     */
    if ((Size > 0) && (rx_callback != NULL))
    {
        rx_callback(
            rx_buffer,
            Size
        );
    }


    /*
     * 重新开启下一帧接收
     */
    HAL_UARTEx_ReceiveToIdle_DMA(
        uart_handle,
        rx_buffer,
        UART_RX_BUFFER_SIZE
    );


    /*
     * 禁止Half Transfer中断
     */
    if (uart_handle->hdmarx != NULL)
    {
        __HAL_DMA_DISABLE_IT(
            uart_handle->hdmarx,
            DMA_IT_HT
        );
    }
}


/* =========================================================
 * UART错误回调
 *
 * 如果出现ORE/FE/NE等错误，
 * 自动重新开启接收。
 * =========================================================
 */

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (uart_handle == NULL)
    {
        return;
    }

    if (huart->Instance != uart_handle->Instance)
    {
        return;
    }


    /*
     * Abort当前接收
     */
    HAL_UART_AbortReceive(huart);


    /*
     * 重新开启DMA + IDLE接收
     */
    HAL_UARTEx_ReceiveToIdle_DMA(
        uart_handle,
        rx_buffer,
        UART_RX_BUFFER_SIZE
    );


    if (uart_handle->hdmarx != NULL)
    {
        __HAL_DMA_DISABLE_IT(
            uart_handle->hdmarx,
            DMA_IT_HT
        );
    }
}
