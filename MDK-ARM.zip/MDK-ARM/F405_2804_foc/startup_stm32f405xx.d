f405_2804_foc\startup_stm32f405xx.o: startup_stm32f405xx.s
