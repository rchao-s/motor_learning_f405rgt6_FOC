#include "foc_cal.h"
#include "arm_math.h"
#include "math.h"
#include "tim.h"
#define CURRENT_LOOP_KP 0.5f
#define CURRENT_LOOP_KI 50.0f
#define PWM_FREQ 10000.0f//10khz
#define T (1.0f/PWM_FREQ)
#define U_DC 12.0f
#define ARR 8400.0f
#define SQRT3 1.7320508075688772f
#define CURRENT_LOOP_FREQ      10000.0f
#define CURRENT_LOOP_TS        (1.0f / CURRENT_LOOP_FREQ)
#define U_DQ_LIMIT             (0.8f * U_DC / 1.73205080757f)


uint16_t CCR1 = 0;
uint16_t CCR2 = 0;
uint16_t CCR3 = 0;
uint16_t sector_debug = 99;

void clarke_park(float Isa,float Isb,float Isc,float theta_e,float *I_d,float *I_q)
{
	float I_alpha	=	2.0f/3.0f	*	(Isa	-	0.5	*	Isb	-	0.5	*	Isc);
	float I_beta	=	2.0f/3.0f	*	(SQRT3/2)*(Isb	-	Isc);
	
	*I_d	=	I_alpha	*	cosf(theta_e) + I_beta	*	sinf(theta_e);
	*I_q	=	-I_alpha*	sinf(theta_e) + I_beta	*	cosf(theta_e);
	
}

void current_loop_PI(float Iq_ref, float Iq, float Id_ref, float Id, float *U_d, float *U_q)
{
    static float integral_d = 0.0f;
    static float integral_q = 0.0f;

    float error_d = Id_ref - Id;
    float error_q = Iq_ref - Iq;

    float integral_d_new = integral_d + CURRENT_LOOP_KI * CURRENT_LOOP_TS * error_d;
    float integral_q_new = integral_q + CURRENT_LOOP_KI * CURRENT_LOOP_TS * error_q;

    float Ud = CURRENT_LOOP_KP * error_d + integral_d_new;
    float Uq = CURRENT_LOOP_KP * error_q + integral_q_new;

    float U_mag = sqrtf(Ud * Ud + Uq * Uq);

    if (U_mag <= U_DQ_LIMIT)
    {
        integral_d = integral_d_new;
        integral_q = integral_q_new;
    }
    else
    {
        float scale = U_DQ_LIMIT / U_mag;
        Ud *= scale;
        Uq *= scale;

        if (Ud * error_d + Uq * error_q <= 0.0f)
        {
            integral_d = integral_d_new;
            integral_q = integral_q_new;
        }
    }

    *U_d = Ud;
    *U_q = Uq;
}
void inverse_park(float U_d ,	float U_q ,float theta_e, float *U_alpha , float *U_beta)
{
	*U_alpha =  U_d *cosf(theta_e) - U_q * sinf(theta_e);
	*U_beta  =	U_d *sinf(theta_e) + U_q * cosf(theta_e);
}


//void sector_cal_And_CCR(float U_alpha, float U_beta)
//{
//    const float VDC = 12.0f;
//    const float ARR_F = 8400.0f;

//    float Ua;
//    float Ub;
//    float Uc;

//    float Umax;
//    float Umin;
//    float Uoffset;

//    float duty_a;
//    float duty_b;
//    float duty_c;

//    Ua = U_alpha;

//    Ub = -0.5f * U_alpha
//         + 0.8660254f * U_beta;

//    Uc = -0.5f * U_alpha
//         - 0.8660254f * U_beta;


//    Umax = Ua;
//    if (Ub > Umax) Umax = Ub;
//    if (Uc > Umax) Umax = Uc;

//    Umin = Ua;
//    if (Ub < Umin) Umin = Ub;
//    if (Uc < Umin) Umin = Uc;


//    /* 注入零序分量 */
//    Uoffset = -0.5f * (Umax + Umin);

//    Ua += Uoffset;
//    Ub += Uoffset;
//    Uc += Uoffset;


//    /*
//     * Ua/Ub/Uc 是以直流母线中点为参考的相电压指令
//     * 转换成 0~1 duty
//     */
//    duty_a = 0.5f + Ua / VDC;
//    duty_b = 0.5f + Ub / VDC;
//    duty_c = 0.5f + Uc / VDC;


//    /* 先做最基本限幅 */
//    if (duty_a > 0.95f) duty_a = 0.95f;
//    if (duty_a < 0.05f) duty_a = 0.05f;

//    if (duty_b > 0.95f) duty_b = 0.95f;
//    if (duty_b < 0.05f) duty_b = 0.05f;

//    if (duty_c > 0.95f) duty_c = 0.95f;
//    if (duty_c < 0.05f) duty_c = 0.05f;


//    CCR1 = (uint16_t)(duty_a * ARR_F);
//    CCR2 = (uint16_t)(duty_b * ARR_F);
//    CCR3 = (uint16_t)(duty_c * ARR_F);


//    __HAL_TIM_SET_COMPARE(
//        &htim1,
//        TIM_CHANNEL_1,
//        CCR1
//    );

//    __HAL_TIM_SET_COMPARE(
//        &htim1,
//        TIM_CHANNEL_2,
//        CCR2
//    );

//    __HAL_TIM_SET_COMPARE(
//        &htim1,
//        TIM_CHANNEL_3,
//        CCR3
//    );
//}


void sector_cal_And_CCR(float U_alpha,float U_beta)
{
	float U_1 = U_beta;
	float U_2 = (SQRT3*U_alpha - U_beta)/2;
	float U_3 = -(SQRT3*U_alpha + U_beta)/2;
	
	float T_0 = 0;
	float T_1 = 0;
	float T_2 = 0;
	float T_3 = 0;
	float T_4 = 0;
	float T_5 = 0;
	float T_6 = 0;
	float T_7 = 0;
//	
//	float CCR1 = 0;
//	float CCR2 = 0;
//	float CCR3 = 0;
	
	float K=SQRT3/U_DC*T;
    uint16_t sector_N = 0;

    if (U_1 > 0.0f) sector_N += 1;
    if (U_2 > 0.0f) sector_N += 2;
    if (U_3 > 0.0f) sector_N += 4;
		sector_debug = sector_N;
	
	switch (sector_N)
	{	
		case 3://扇区1
		{
			T_4 = U_2 * K;
			T_6 = U_1 * K;
			T_0 = T_7 = (T - T_4 - T_6)/2;
			
			CCR1 =	(T_7 + T_6 + T_4) / T* ARR;
			CCR2 =	(T_7 + T_6 ) 			/ T* ARR;
			CCR3 =	(T_7 ) 						/ T* ARR;

			break;
		}
		case 1://扇区2
		{
			T_6 = -U_3 * K;
			T_2 = -U_2 * K;
			T_0 = T_7 = (T - T_2 - T_6)/2;
			
			CCR1 =	(T_7 + T_6) 			/ T* ARR;
			CCR2 =	(T_7 + T_6 + T_2) / T* ARR;
			CCR3 =	(T_7 ) 						/ T* ARR;
			

			break;
		}
		case 5://扇区3
		{
			T_2 = U_1 * K;
			T_3 = U_3 * K;
			T_0 = T_7 = (T - T_2 - T_3)/2;
					
			CCR1 =	(T_7 ) 						/ T* ARR;
			CCR2 =	(T_7 + T_3 + T_2) / T* ARR;
			CCR3 =	(T_7 + T_3) 			/ T* ARR;

			break;
		}
		case 4://扇区4
		{
			T_1 = -U_1 * K;
			T_3 = -U_2 * K;
			T_0 = T_7 = (T - T_1 - T_3)/2;
			
			CCR1 =	(T_7 ) 						/ T* ARR;
			CCR2 =	(T_7 + T_3 ) 			/ T* ARR;
			CCR3 =	(T_7 + T_3 + T_1) / T* ARR;

			break;
		}
		case 6://扇区5
		{
			T_1 = U_3 * K;
			T_5 = U_2 * K;
			T_0 = T_7 = (T - T_1 - T_5)/2;
			
			CCR1 =	(T_7 + T_5) 			/ T* ARR;
			CCR2 =	(T_7 ) 						/ T* ARR;
			CCR3 =	(T_7 + T_5 + T_1)	/ T* ARR;
		
			break;
		}
		case 2://扇区6
		{
			T_4 = -U_3 * K;
			T_5 = -U_1 * K;
			T_0 = T_7 = (T - T_4 - T_5)/2;
			
			CCR1 =	(T_7 + T_5 + T_4) / T* ARR;
			CCR2 =	(T_7 ) 						/ T* ARR;
			CCR3 =	(T_7 + T_5 )			/ T* ARR;

			
			break;
		}		
	}
	
			if (CCR1>=7000) CCR1=7000;
			if (CCR2>=7000) CCR2=7000;
			if (CCR3>=7000) CCR3=7000;
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, CCR1);
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, CCR2);
			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, CCR3);
 

}
