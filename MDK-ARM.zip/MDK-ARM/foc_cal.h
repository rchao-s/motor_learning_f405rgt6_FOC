#warning "FOC_CAL.H REALLY INCLUDED"

#ifndef FOC_CAL_
#define FOC_CAL_
#include "stm32f4xx_hal.h"



extern	float Isa;
extern	float Isb;
extern	float Isc;

extern uint16_t CCR1;
extern uint16_t CCR2;
extern uint16_t CCR3;
extern uint16_t sector_debug;
extern  float theta_e;

void speed_loop_PI(float speed_ref, float speed, float *Iq_ref);

void clarke_park(float Isa,float Isb,float Isc,float theta_e,float *I_d,float *i_q);

void current_loop_PI(float Iq_ref,float Iq,float Id_ref,float Id,float *U_d,float *U_q);

void inverse_park(float U_d ,	float U_q ,float theta_e, float *U_alpha , float *U_beta);

void sector_cal_And_CCR(float U_alpha,float U_beta);
////////////////////////////////////////////////////////////////////////////////////
void foc_observer_init(float theta_mech_rad);                  // 初始化位置速度估算

void foc_observer_run(float theta_meas_rad);                   // 10kHz运行位置速度估算

void foc_observer_get(float theta_m2e_deg, float *theta_e, float *speed_rpm); // 获取电角度和转速


#endif

