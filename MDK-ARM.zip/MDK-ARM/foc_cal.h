#ifndef FOC_CAL_
#define FOC_CAL_
#include "stm32f4xx_hal.h"

#warning "THIS IS THE FOC_CAL.H USED BY MAIN"

extern	float Isa;
extern	float Isb;
extern	float Isc;

extern uint16_t CCR1;
extern uint16_t CCR2;
extern uint16_t CCR3;
extern uint16_t sector_debug;
extern  float theta_e;

void clarke_park(float Isa,float Isb,float Isc,float theta_e,float *I_d,float *i_q);

void current_loop_PI(float Iq_ref,float Iq,float Id_ref,float Id,float *U_d,float *U_q);

void inverse_park(float U_d ,	float U_q ,float theta_e, float *U_alpha , float *U_beta);

void sector_cal_And_CCR(float U_alpha,float U_beta);

#endif

