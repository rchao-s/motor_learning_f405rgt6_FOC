#ifndef UART_TR_H
#define UART_TR_H

#include "stm32f4xx_hal.h"
#include <stdint.h>

/* 缓冲区大小 */
#define UART_TX_BUFFER_SIZE    256
#define UART_RX_BUFFER_SIZE    128
extern float speed_ref;
/*
 * 初始化
 * 示例：
 * UART_TR_Init(&huart3);
 */
void UART_TR_Init(UART_HandleTypeDef *huart);


/*
 * DMA发送原始数据
 *
 * 返回：
 * 1 = 成功启动发送
 * 0 = UART忙 / 参数错误
 */
uint8_t UART_TR_SendData(const uint8_t *data, uint16_t len);


/*
 * printf格式发送
 *
 * 示例：
 * UART_printf("Ia: %.2f Ib: %.2f\r\n", Ia, Ib);
 *
 * 注意：
 * 上一次DMA没结束时，本次数据会直接丢弃。
 */
void UART_printf(const char *format, ...);


/*
 * 开启 DMA + IDLE 接收
 */
void UART_TR_StartReceiving(void);


/*
 * 注册接收回调
 *
 * 示例：
 *
 * void My_UART_RxCallback(uint8_t *data, uint16_t len)
 * {
 * }
 *
 * UART_TR_RegisterRxCallback(My_UART_RxCallback);
 */
void UART_TR_RegisterRxCallback(
    void (*callback)(uint8_t *data, uint16_t len)
);


/*
 * 查询发送是否正在进行
 *
 * 1 = DMA正在发送
 * 0 = 空闲
 */
uint8_t UART_TR_IsTxBusy(void);


#endif
