#include "adc_sa.h"

#define CURRENT_GAIN 50.0f
#define PI 3.1415926f
float psa_value_deg;
float psa_value_rad;
float Isa_value_A;
float Isb_value_A;
float Isc_value_A;

float Isa;
float Isb;
float Isc;
float Is_common;


uint16_t	adc_psa_raw;
uint16_t	adc_Isa_raw;
uint16_t	adc_Isb_raw;
uint16_t	adc_Isc_raw;

static uint16_t sa_cnt=0;
static uint16_t adc_offset_done=0;

void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef *hadc)
{
	static uint32_t adc_Isa_sum	=	0;
	static uint32_t adc_Isb_sum	=	0;
	static uint32_t adc_Isc_sum	=	0;
	
	static uint16_t adc_Isa_offset	=	2048;
	static uint16_t adc_Isb_offset	=	2048;
	static uint16_t adc_Isc_offset	=	2048;

	
	if(hadc->Instance==ADC1)
	{

		adc_psa_raw	=	HAL_ADCEx_InjectedGetValue(&hadc1,ADC_INJECTED_RANK_1);//as5600传 感器
		adc_Isa_raw	=	HAL_ADCEx_InjectedGetValue(&hadc1,ADC_INJECTED_RANK_2);//a,b,c相电流
		adc_Isb_raw	=	HAL_ADCEx_InjectedGetValue(&hadc1,ADC_INJECTED_RANK_3);
		adc_Isc_raw	=	HAL_ADCEx_InjectedGetValue(&hadc1,ADC_INJECTED_RANK_4);
	
		if(system_state==IDLE&&adc_offset_done==0)
		{		
			adc_Isa_sum += adc_Isa_raw;
			adc_Isb_sum	+= adc_Isb_raw;
			adc_Isc_sum	+= adc_Isc_raw;
			sa_cnt++;
			
			if(sa_cnt>=5000){
				adc_Isa_offset = adc_Isa_sum/5000;
				adc_Isb_offset = adc_Isb_sum/5000;
				adc_Isc_offset = adc_Isc_sum/5000;
				adc_offset_done=1;
			}
		}
		
		psa_value_deg	=	adc_psa_raw/4095.0f*360;
		psa_value_rad	=	adc_psa_raw/4095.0f*(2*PI);
		Isa_value_A	=	(adc_Isa_raw	-	adc_Isa_offset)*3.3f/4095.0f*CURRENT_GAIN;
		Isb_value_A =	(adc_Isb_raw	-	adc_Isb_offset)*3.3f/4095.0f*CURRENT_GAIN;
		Isc_value_A =	(adc_Isc_raw	-	adc_Isc_offset)*3.3f/4095.0f*CURRENT_GAIN;
		
		Is_common=(Isa_value_A+Isb_value_A+Isc_value_A)/3.0f;
		
		Isa	=	Isa_value_A	-	Is_common;
		Isb	=	Isb_value_A	-	Is_common;
		Isc	=	Isc_value_A	-	Is_common;
		
	}

}
