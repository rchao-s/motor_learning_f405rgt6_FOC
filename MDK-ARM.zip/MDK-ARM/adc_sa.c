#include "adc_sa.h"
#include "foc_cal.h"

#define CURRENT_GAIN 50.0f
#define PI 3.1415926f
float psa_value_deg;
float psa_value_rad;
float Isa_value_A;
float Isb_value_A;
float Isc_value_A;

float Isa;
float Isb;
float Isc;
float Is_common;

float I_d;
float I_q;

float	Id_ref=0;
float	Iq_ref=0.3;

float U_d;
float U_q;
float U_alpha;
float U_beta;


float	psa_e;
float	theta_m2e;//机械角度与电角度的差值
float	theta_e;
float theta_e_deg;

//uint16_t CCR1 = 50;
//uint16_t CCR2 = 50;
//uint16_t CCR3 = 50;

uint16_t	adc_psa_raw;
uint16_t	adc_Isa_raw;
uint16_t	adc_Isb_raw;
uint16_t	adc_Isc_raw;

static uint16_t sa_cnt=0;
uint16_t adc_offset_done=0;

void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef *hadc)
{
		static uint32_t adc_Isa_sum = 0;
    static uint32_t adc_Isb_sum = 0;
    static uint32_t adc_Isc_sum = 0;

    static uint16_t adc_Isa_offset = 2048;
    static uint16_t adc_Isb_offset = 2048;
    static uint16_t adc_Isc_offset = 2048;

    if(hadc->Instance == ADC1)
    {
        adc_psa_raw = HAL_ADCEx_InjectedGetValue(&hadc1,ADC_INJECTED_RANK_1);

        adc_Isa_raw = HAL_ADCEx_InjectedGetValue(&hadc1,ADC_INJECTED_RANK_2);

        adc_Isb_raw = HAL_ADCEx_InjectedGetValue(&hadc1,ADC_INJECTED_RANK_3);

        adc_Isc_raw = HAL_ADCEx_InjectedGetValue(&hadc1,ADC_INJECTED_RANK_4);
       
				psa_value_deg = adc_psa_raw / 4095.0f * 360.0f;

        psa_value_rad = adc_psa_raw / 4095.0f * (2.0f * PI);

        if(system_state == IDLE)
        {
            if(adc_offset_done == 0)
            {
                adc_Isa_sum += adc_Isa_raw;
                adc_Isb_sum += adc_Isb_raw;
                adc_Isc_sum += adc_Isc_raw;

                sa_cnt++;

                if(sa_cnt >= 5000)
                {
                    adc_Isa_offset =	adc_Isa_sum / 5000;
                    adc_Isb_offset =	adc_Isb_sum / 5000;
                    adc_Isc_offset =	adc_Isc_sum / 5000;

                    adc_offset_done = 1;
                }
            }

            return;
        }



//        if(system_state == STARTING)//校准机械角度与电角度的差值
//        {
//            Isa_value_A =((int32_t)adc_Isa_raw -(int32_t)adc_Isa_offset)* 3.3f / 4095.0f* CURRENT_GAIN;
//            Isb_value_A =((int32_t)adc_Isb_raw -(int32_t)adc_Isb_offset)* 3.3f / 4095.0f* CURRENT_GAIN;
//            Isc_value_A =((int32_t)adc_Isc_raw -(int32_t)adc_Isc_offset)* 3.3f / 4095.0f* CURRENT_GAIN;

//            Is_common =(Isa_value_A + Isb_value_A + Isc_value_A) / 3.0f;

//            Isa = Isa_value_A - Is_common;
//            Isb = Isb_value_A - Is_common;
//            Isc = Isc_value_A - Is_common;

//            return;
//        }

        if(system_state == RUNNING)
        {
	
          theta_e_deg = psa_value_deg * 7.0f + theta_m2e;
						
					while(theta_e_deg >= 360.0f)
					{
							theta_e_deg -= 360.0f;
					}
					
					while(theta_e_deg < 0.0f)
					{
							theta_e_deg += 360.0f;
					}
					
					/* FOC 内统一使用 rad */
					theta_e =theta_e_deg * PI / 180.0f;


         Isa_value_A =((int32_t)adc_Isa_raw -(int32_t)adc_Isa_offset)* 3.3f / 4095.0f* CURRENT_GAIN;
         Isb_value_A =((int32_t)adc_Isb_raw -(int32_t)adc_Isb_offset)* 3.3f / 4095.0f* CURRENT_GAIN;
         Isc_value_A =((int32_t)adc_Isc_raw -(int32_t)adc_Isc_offset)* 3.3f / 4095.0f* CURRENT_GAIN;

         Is_common =(Isa_value_A + Isb_value_A + Isc_value_A) / 3.0f;

         Isa = Isa_value_A - Is_common;
         Isb = Isb_value_A - Is_common;
         Isc = Isc_value_A - Is_common;
		
	
	
						clarke_park(	Isa,	Isb,	Isc,	theta_e,&I_d,	&I_q);
	
						current_loop_PI(	Iq_ref,	I_q,	Id_ref,	I_d,	&U_d,	&U_q);
						
						inverse_park(U_d ,	U_q ,theta_e, &U_alpha ,&U_beta);
						
						sector_cal_And_CCR(U_alpha,U_beta);
		}
	
	}
}
