#ifndef ADC_SAMPLE
#define ADC_SAMPLE
#include "stm32f4xx_hal.h"

typedef enum {
    IDLE,
    STARTING,
    RUNNING,
    FAULT,
    STOPPING
} SystemState_t;

extern SystemState_t system_state;

extern ADC_HandleTypeDef hadc1;

extern float psa_value_deg;
extern float psa_value_rad;
extern float Isa_value_A;
extern float Isb_value_A;
extern float Isc_value_A;

extern	float Isa;
extern	float Isb;
extern	float Isc;
extern  float	theta_e;
extern  float	theta_m2e;
extern uint16_t adc_offset_done;

extern  float	Id_ref;
extern  float	Iq_ref;

extern  float	I_d;
extern  float	I_q;
extern  float U_d;
extern  float U_q;
extern uint16_t adc_Isa_offset;
extern uint16_t adc_Isb_offset;
extern uint16_t adc_Isc_offset;

extern uint16_t	adc_psa_raw;
extern uint16_t	adc_Isa_raw;
extern uint16_t	adc_Isb_raw;
extern uint16_t	adc_Isc_raw;

void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef *hadc);

#endif

